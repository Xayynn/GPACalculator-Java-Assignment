/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycomputer.gpaapp;
import java.util.Scanner;
import java.text.DecimalFormat;
/**
 *
 * @author Aliyu Aliyu
 */
public class GpaAPP {

 

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Input Student Name
        System.out.println("Enter student Firstname: ");
        String fname = scanner.next();
        System.out.println("Enter student Lastname: ");
        String lname = scanner.next();
        // Input the number of courses
        System.out.print("Enter the number of courses: ");
        int numCourses = scanner.nextInt();

        // Arrays to store course names, credit units, and scores
        String[] courseNames = new String[numCourses];
        int[] gradeUnits = new int[numCourses];
        double[] scores = new double[numCourses];

        // Input information for each course
        for (int i = 0; i < numCourses; i++) {
            System.out.println("\nEnter details for Course " + (i + 1) + ":");
            System.out.print("Course Name: ");
            courseNames[i] = scanner.next();
            System.out.print("Credit Units: ");
            gradeUnits[i] = scanner.nextInt();
            System.out.print("Score: ");
            scores[i] = scanner.nextDouble();
        }

        // Calculate grades and print the table
        System.out.println("\nGrades and Credit Units Table Of :" +fname+ " " +lname);
        System.out.println("+-------------|-------------|-------------|---------+");
        System.out.printf("%-15s%-15s%-15s%-15s%n", "Course", "Credit Units", "Grade-Unit", "Grade");
        System.out.println("+-------------|-------------|-------------|---------+");

        int totalQualityPoints = 0;
        int totalGradeUnits = 0;

        for (int i = 0; i < numCourses; i++) {
            String grade = calculateGrade(scores[i]);
            int gradePoint = calculateGradePoint(scores[i]);

            totalQualityPoints += gradePoint * gradeUnits[i];
            totalGradeUnits += gradeUnits[i];

            System.out.printf("%-15s%-15d%-15d%-15s%n", courseNames[i], gradeUnits[i], gradePoint, grade);
        }

        double gpa = (double) totalQualityPoints / totalGradeUnits;

        System.out.println("+-------------|-------------|-------------|---------+");
         // Format GPA to two decimal places
        DecimalFormat df = new DecimalFormat("#.##");
        String formattedGPA = df.format(gpa);

        System.out.println("\nTotal GPA: " + formattedGPA);

        scanner.close();

//        System.out.println("Total GPA: " + gpa);
    }

    // Method to calculate the grade based on the score
    private static String calculateGrade(double score) {
        if (score >= 70) {
            return "A";
        } else if (score >= 60) {
            return "B";
        } else if (score >= 50) {
            return "C";
        } else if (score >= 45) {
            return "D";
        } else if (score >= 40) {
            return "E";
        } else {
            return "F";
        }
    }

    // Method to calculate the gradepoint based on the score
    private static int calculateGradePoint(double score) {
        if (score >= 70) {
            return 5;
        } else if (score >= 60) {
            return 4;
        } else if (score >= 50) {
            return 3;
        } else if (score >= 45) {
            return 2;
        } else if (score >= 40) {
            return 1;
        } else {
            return 0;
        }
    }

}
